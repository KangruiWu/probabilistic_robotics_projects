Student: Kangrui Wu

Please use jupyter notebook to open KF.ipynb.

KF.ipynb contains codes for 1.3, 1.4, 2.2, 2.3, 3.1.

You can also see codes from KF_python_code pdf file, and for hand writing notes, please go to  KF_python_code pdf file.

